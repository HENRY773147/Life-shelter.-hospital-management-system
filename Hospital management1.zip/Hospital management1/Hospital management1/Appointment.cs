﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Hospital_management1
{
    public partial class Appointment : Form
    {
        public Appointment()
        {
            InitializeComponent();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            int aid = int.Parse(textBox1.Text);
            String patientname = textBox2.Text;
            String doctorname = textBox3.Text;
            String status = textBox4.Text;
            String date_created = dateTimePicker1.Value.ToString("dd-mm-yyyy");

            String query = "insert into appointment(aid,patientname,doctorname,status,date_created) values(@aid,@patientname,@doctorname,@status,@date_created)";
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\Documents\hospitalDB.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@AID", aid);
                    cmd.Parameters.AddWithValue("@PatientName", patientname);
                    cmd.Parameters.AddWithValue("@DoctorName", doctorname);
                    cmd.Parameters.AddWithValue("@Status", status);
                    cmd.Parameters.AddWithValue("@Date_Created", date_created);
                    cmd.ExecuteNonQuery();
                }
            }
            MessageBox.Show(" Appointment created Successfully");
            AppointmentData();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int aid = int.Parse(textBox1.Text);
            String patientname = textBox2.Text;
            String doctorname = textBox3.Text;
            String status = textBox4.Text;
            String date_created = dateTimePicker1.Value.ToString("dd-mm-yyyy");

            String query = "update appointment set patientname=@patientname,doctorname=@doctorname,date_created=@date_created where aid=@aid";
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\Documents\hospitalDB.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@AID", aid);
                    cmd.Parameters.AddWithValue("@PatientName", patientname);
                    cmd.Parameters.AddWithValue("@DoctorName", doctorname);
                    cmd.Parameters.AddWithValue("@Status", status);
                    cmd.Parameters.AddWithValue("@Date_Created", date_created);
                    cmd.ExecuteNonQuery();
                }
            }
            MessageBox.Show("record updated Successfully");
            AppointmentData();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int aid = int.Parse(textBox1.Text);


            String query = "delete from appointment where aid=@aid";
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\Documents\hospitalDB.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@AID", aid);
                    cmd.ExecuteNonQuery();
                }
            }
            MessageBox.Show("Record Deleted Successfully");
            AppointmentData();
        }

        private void Appointment_Load(object sender, EventArgs e)
        {
            AppointmentData();
        }
        private void AppointmentData()
        {
            String query = "select * from appointment";
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\Documents\hospitalDB.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        dataGridView1.DataSource = dataTable;
                    }
                }
            }

        }
    }
}
