﻿namespace Hospital_management1
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            panel1 = new Panel();
            label1 = new Label();
            panel3 = new Panel();
            lblCount1 = new Label();
            panel4 = new Panel();
            lblCount2 = new Label();
            panel5 = new Panel();
            lblCount3 = new Label();
            panel2 = new Panel();
            lblCount4 = new Label();
            sqlCommand1 = new Microsoft.Data.SqlClient.SqlCommand();
            panel1.SuspendLayout();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.DimGray;
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1023, 80);
            panel1.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.DimGray;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(46, 18);
            label1.Name = "label1";
            label1.Size = new Size(553, 48);
            label1.TabIndex = 0;
            label1.Text = "Life Shelter Hospital Dashboard";
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(255, 192, 128);
            panel3.BorderStyle = BorderStyle.Fixed3D;
            panel3.Controls.Add(lblCount1);
            panel3.Location = new Point(57, 165);
            panel3.Name = "panel3";
            panel3.Size = new Size(383, 121);
            panel3.TabIndex = 4;
            panel3.Paint += panel3_Paint;
            // 
            // lblCount1
            // 
            lblCount1.AutoSize = true;
            lblCount1.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lblCount1.Location = new Point(16, 48);
            lblCount1.Name = "lblCount1";
            lblCount1.Size = new Size(28, 32);
            lblCount1.TabIndex = 1;
            lblCount1.Text = "0";
            // 
            // panel4
            // 
            panel4.BackColor = Color.FromArgb(255, 192, 128);
            panel4.BorderStyle = BorderStyle.Fixed3D;
            panel4.Controls.Add(lblCount2);
            panel4.Location = new Point(492, 165);
            panel4.Name = "panel4";
            panel4.Size = new Size(374, 121);
            panel4.TabIndex = 5;
            // 
            // lblCount2
            // 
            lblCount2.AutoSize = true;
            lblCount2.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lblCount2.Location = new Point(16, 48);
            lblCount2.Name = "lblCount2";
            lblCount2.Size = new Size(28, 32);
            lblCount2.TabIndex = 2;
            lblCount2.Text = "0";
            lblCount2.Click += lblCount2_Click;
            // 
            // panel5
            // 
            panel5.BackColor = Color.FromArgb(255, 192, 128);
            panel5.BorderStyle = BorderStyle.Fixed3D;
            panel5.Controls.Add(lblCount3);
            panel5.Location = new Point(492, 356);
            panel5.Name = "panel5";
            panel5.Size = new Size(374, 113);
            panel5.TabIndex = 6;
            // 
            // lblCount3
            // 
            lblCount3.AutoSize = true;
            lblCount3.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lblCount3.Location = new Point(16, 43);
            lblCount3.Name = "lblCount3";
            lblCount3.Size = new Size(28, 32);
            lblCount3.TabIndex = 3;
            lblCount3.Text = "0";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(255, 192, 128);
            panel2.BorderStyle = BorderStyle.Fixed3D;
            panel2.Controls.Add(lblCount4);
            panel2.Location = new Point(57, 356);
            panel2.Name = "panel2";
            panel2.Size = new Size(383, 113);
            panel2.TabIndex = 7;
            // 
            // lblCount4
            // 
            lblCount4.AutoSize = true;
            lblCount4.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lblCount4.Location = new Point(16, 43);
            lblCount4.Name = "lblCount4";
            lblCount4.Size = new Size(28, 32);
            lblCount4.TabIndex = 4;
            lblCount4.Text = "0";
            // 
            // sqlCommand1
            // 
            sqlCommand1.CommandTimeout = 30;
            sqlCommand1.EnableOptimizedParameterBinding = false;
            // 
            // Dashboard
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 255, 128);
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(1023, 596);
            Controls.Add(panel2);
            Controls.Add(panel3);
            Controls.Add(panel5);
            Controls.Add(panel4);
            Controls.Add(panel1);
            Name = "Dashboard";
            Text = "Dashboard";
            Load += Dashboard_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Label label1;
        private Panel panel3;
        private Panel panel4;
        private Panel panel5;
        private Panel panel2;
        private Label lblCount1;
        private Label lblCount2;
        private Label lblCount3;
        private Label lblCount4;
        private Microsoft.Data.SqlClient.SqlCommand sqlCommand1;
    }
}