﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_management1
{
    public partial class Doctor : Form
    {
        public Doctor()
        {
            InitializeComponent();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            int doctorid = int.Parse(textBox1.Text);
            String doctorname = textBox2.Text;
            String speciality = textBox3.Text;
            String phone = textBox4.Text;
            String department = textBox5.Text;

            String query = "insert into doctor(doctorid,doctorname,speciality,phone,department) values(@doctorid,@doctorname,@speciality,@phone,@department)";
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\Documents\hospitalDB.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@DoctorID", doctorid);
                    cmd.Parameters.AddWithValue("@DoctorName", doctorname);
                    cmd.Parameters.AddWithValue("@Speciality", speciality);
                    cmd.Parameters.AddWithValue("@Phone", phone);
                    cmd.Parameters.AddWithValue("@Department", department);
                    cmd.ExecuteNonQuery();
                }
            }
            MessageBox.Show("Doctor Added Successfully");
            DoctorData();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int doctorid = int.Parse(textBox1.Text);
            String doctorname = textBox2.Text;
            String speciality = textBox3.Text;
            String phone = textBox4.Text;
            String department = textBox5.Text;

            String query = "update doctor set doctorname=@doctorname,speciality=@speciality,phone=@phone,department=@department where doctorid=@doctorid";
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\Documents\hospitalDB.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@DoctorID", doctorid);
                    cmd.Parameters.AddWithValue("@DoctorName", doctorname);
                    cmd.Parameters.AddWithValue("@Phone", phone);
                    cmd.Parameters.AddWithValue("@Speciality", speciality);
                    cmd.Parameters.AddWithValue("@Department", department);
                    cmd.ExecuteNonQuery();
                }
            }
            MessageBox.Show("record updated Successfully");
            DoctorData();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int doctorid = int.Parse(textBox1.Text);


            String query = "delete from doctor where doctorid=@doctorid";
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\Documents\hospitalDB.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@DoctorID", doctorid);
                    cmd.ExecuteNonQuery();
                }
            }
            MessageBox.Show("Record Deleted Successfully");
            DoctorData();
        }

        private void Doctor_Load(object sender, EventArgs e)
        {
            DoctorData();
        }

        private void DoctorData() 
        {
            String query = "select * from doctor";
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\Documents\hospitalDB.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        dataGridView1.DataSource = dataTable;
                    }
                }
            }
        }
    }
}
