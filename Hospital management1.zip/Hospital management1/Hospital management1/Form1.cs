namespace Hospital_management1
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
          if(txtUsername.Text =="admin" && txtPassword.Text == "1234")
            {
                Main mn = new Main();
                mn.Show();
            }
            else if(txtUsername.Text !="acdb"||txtPassword.Text !="1234")
            {
                MessageBox.Show("Invalid username or Password");
            }
        }
    }
}
