﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_management1
{
    public partial class MedicalRecord : Form
    {
        public MedicalRecord()
        {
            InitializeComponent();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            int mid = int.Parse(textBox1.Text);
            String patientname = textBox2.Text;
            String doctorname = textBox3.Text;
            String nurse = textBox4.Text;
            String diagnosis = textBox5.Text;
            String prescription = textBox6.Text;
            String treatment = textBox7.Text;


            String query = "insert into record(mid,patientname,doctorname,nurse,diagnosis,prescription,treatment) values(@mid,@patientname,@doctorname,@nurse,@diagnosis,@prescription,@treatment)";
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\Documents\hospitalDB.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@MID", mid);
                    cmd.Parameters.AddWithValue("@PatientName", patientname);
                    cmd.Parameters.AddWithValue("@DoctorName", doctorname);
                    cmd.Parameters.AddWithValue("@Nurse", nurse);
                    cmd.Parameters.AddWithValue("@Diagnosis", diagnosis);
                    cmd.Parameters.AddWithValue("@Prescription", prescription);
                    cmd.Parameters.AddWithValue("@Treatment", treatment);

                    cmd.ExecuteNonQuery();
                }
            }
            MessageBox.Show(" Medi.Record Added Successfully");
            RecordData();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int mid = int.Parse(textBox1.Text);
            String patientname = textBox2.Text;
            String doctorname = textBox3.Text;
            String nurse = textBox4.Text;
            String diagnosis = textBox5.Text;
            String prescription = textBox6.Text;
            String treatment = textBox7.Text;

            String query = "update record set patientname=@patientname,doctorname=@doctorname,nurse=@nurse,diagnosis=@diagnosis, prescription=@prescription,treatment=@treatment where mid=@mid";
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\Documents\hospitalDB.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@MID", mid);
                    cmd.Parameters.AddWithValue("@PatientName", patientname);
                    cmd.Parameters.AddWithValue("@DoctorName", doctorname);
                    cmd.Parameters.AddWithValue("@Nurse", nurse);
                    cmd.Parameters.AddWithValue("@Diagnosis", diagnosis);
                    cmd.Parameters.AddWithValue("@Prescription", prescription);
                    cmd.Parameters.AddWithValue("@Treatment", treatment);
                }
            }
            MessageBox.Show("record updated Successfully");
            RecordData();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int mid = int.Parse(textBox1.Text);


            String query = "delete from record where mid=@mid";
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\Documents\hospitalDB.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@MID", mid);
                    cmd.ExecuteNonQuery();
                }
            }
            MessageBox.Show("Record Deleted Successfully");
            RecordData();
        }

        private void MedicalRecord_Load(object sender, EventArgs e)
        {
            RecordData();
        }
        private void RecordData()
        {
            String query = "select * from record";
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\Documents\hospitalDB.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        dataGridView1.DataSource = dataTable;
                    }
                }
            }
        }
    }
}
