﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Hospital_management1
{
    public partial class Nurse : Form
    {
        public Nurse()
        {
            InitializeComponent();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            int nurseid = int.Parse(textBox1.Text);
            String nursename = textBox2.Text;
            String phone = textBox3.Text;
            String department = textBox4.Text;


            String query = "insert into nurse(nurseid,nursename,phone,department) values(@nurseid,@nursename,@phone,@department)";
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\Documents\hospitalDB.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@NurseID", nurseid);
                    cmd.Parameters.AddWithValue("@NurseName", nursename);
                    cmd.Parameters.AddWithValue("@Phone", phone);
                    cmd.Parameters.AddWithValue("@Department", department);
                    cmd.ExecuteNonQuery();
                }
            }
            MessageBox.Show("Nurse Added Successfully");
            NurseData();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int nurseid = int.Parse(textBox1.Text);
            String nursename = textBox2.Text;
            String phone = textBox3.Text;
            String department = textBox4.Text;

            String query = "update nurse set nursename=@nursename,phone=@phone,department=@department where nurseid=@nurseid";
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\Documents\hospitalDB.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@NurseID", nurseid);
                    cmd.Parameters.AddWithValue("@NurseName", nursename);
                    cmd.Parameters.AddWithValue("@Phone", phone);
                    cmd.Parameters.AddWithValue("@Department", department);
                    cmd.ExecuteNonQuery();
                }
            }
            MessageBox.Show("record updated Successfully");
            NurseData();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int nurseid = int.Parse(textBox1.Text);


            String query = "delete from nurse where nurseid=@nurseid";
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\Documents\hospitalDB.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@NurseID", nurseid);
                    cmd.ExecuteNonQuery();
                }
            }
            MessageBox.Show("Record Deleted Successfully");
            NurseData();
        }

        private void Nurse_Load(object sender, EventArgs e)
        {
            NurseData();
        }
        private void NurseData()
        {
            String query = "select * from nurse";
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\Documents\hospitalDB.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        dataGridView1.DataSource = dataTable;
                    }
                }
            }
        }


    }
}
